import pandas

obj = pandas.read_pickle(r"winner.pkl")

print(type(obj))